
const userModel = require('../models/userModel');

exports.createUser = async (req, res, next) => {
    try {
        const { username, email, password } = req.body;
        const newUser = await userModel.create({ username, email, password })
        await newUser.save();
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error during registration' });
    }

}