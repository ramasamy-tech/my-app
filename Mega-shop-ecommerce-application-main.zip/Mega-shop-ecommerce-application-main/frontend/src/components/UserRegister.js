import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const formContainerStyle = {
  maxWidth: '400px',
  margin: '40px auto',
  padding: '32px 24px',
  background: '#fff',
  borderRadius: '8px',
  boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
};

const formGroupStyle = {
  display: 'flex',
  flexDirection: 'column',
  marginBottom: '18px',
};

const labelStyle = {
  marginBottom: '6px',
  fontWeight: '500',
  fontSize: '16px',
};

const inputStyle = {
  padding: '10px 12px',
  border: '1px solid #ccc',
  borderRadius: '4px',
  fontSize: '15px',
  outline: 'none',
};

const errorStyle = {
  color: 'red',
  fontSize: '13px',
  marginTop: '4px',
};

const buttonStyle = {
  width: '100%',
  padding: '12px',
  background: '#fa9c23',
  color: '#fff',
  border: 'none',
  borderRadius: '4px',
  fontWeight: 'bold',
  fontSize: '16px',
  cursor: 'pointer',
  marginTop: '10px',
};

const headingStyle = {
  textAlign: 'center',
  marginBottom: '24px',
  fontWeight: '600',
  fontSize: '28px',
};

const UserRegister = () => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const validate = () => {
    let errs = {};

    if (!formData.username.trim()) errs.username = 'Username is required';
    if (!formData.email.trim()) {
      errs.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errs.email = 'Email is invalid';
    }
    if (formData.password.length < 6)
      errs.password = 'Password must be at least 6 characters';

    return errs;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      fetch(process.env.REACT_APP_API_URL + '/user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      }).then(() => {
        setSubmitted(true);
        localStorage.setItem('user', formData.email)
        setTimeout(() => navigate('/'), 1200);
      });
    }
  };

  return (
    <div style={formContainerStyle}>
      <h2 style={headingStyle}>User Registration</h2>
      {submitted && <p style={{ color: 'green', textAlign: 'center' }}>Registration successful!</p>}
      <form onSubmit={handleSubmit} noValidate>
        <div style={formGroupStyle}>
          <label style={labelStyle}>Username</label>
          <input
            style={inputStyle}
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
          />
          {errors.username && <span style={errorStyle}>{errors.username}</span>}
        </div>

        <div style={formGroupStyle}>
          <label style={labelStyle}>Email</label>
          <input
            style={inputStyle}
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
          />
          {errors.email && <span style={errorStyle}>{errors.email}</span>}
        </div>

        <div style={formGroupStyle}>
          <label style={labelStyle}>Password</label>
          <input
            style={inputStyle}
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
          />
          {errors.password && <span style={errorStyle}>{errors.password}</span>}
        </div>

        <button type="submit" style={buttonStyle}>Register</button>
      </form>
    </div>
  );
};

export default UserRegister;