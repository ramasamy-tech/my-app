E-Commerce Website

	A full-stack e-commerce application built with *Node.js, **React, and **MongoDB*.  
	It provides features for browsing products, manging cart and handling checkout.


1) Setup Instructions

	### Prerequisites
	Make sure you have installed:
	-  Node.js
	-  React Js
	-  MongoDB

	Setup Frontend & Backend like below using 

		Frontend: http://localhost:3000
		Backend API: http://localhost:8000/api/v1/


2) Architecture and Components

	The project follows a Micro services architecture with clear separation of concerns.

	Pages: Signup, Login, Product Listing, Cart.

	Frontend (React) & backend Will be deployed separetly.

	Front end communicates with backend via rest APIs.

	Backend (Node.js + Express)

	RESTful API to handle requests from the frontend

	Authentication are using Oauth

	Validation and error handling done using middleware

	Database Tables: users, products and orders data


3) Technology Stack Used

	Frontend
		React.js
		Bootstrap 

	Backend
		Node.js
		Express.js
		Mongoose

	Database
		MongoDB 

	Development Tools
		Git & GitHub
		Visual studio editor